function notify(){
   alert("the Menu Item is added into the cart ");
}