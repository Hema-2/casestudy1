var x=0;
var array=Array();
var price=Array();
var date=Array();
var category=Array();
var y=0;
var z=0;
function myfunction(){
array[x]=document.getElementById("title").value;
price[y]=document.getElementById("price").value;
date[z]=document.getElementById("dateOfLaunch").value;
 if(array[x]=="")
    alert("Title is required.\nTitle should have 2 to 65 characters."); 
 if(price[y]=="")
      alert("Price is required.\nPrice has to be a number.");
 if(date[z]=="")
     alert("Date of Launch is required");
  
    
     
}



              
              
