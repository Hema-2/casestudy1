function alertit(){
   alert("the item is deleted from cart successfully");
}